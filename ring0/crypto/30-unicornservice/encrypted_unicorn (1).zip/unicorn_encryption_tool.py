#!/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# Happy Birthday Mr.Un1k0d3r, 2017
# Theme request by DukeFleed_UaaS
#  --[ Ringzer0team * Towel ]--

from Crypto.Cipher import AES
from Crypto import Random
import hashlib
import base64
import zlib
import sys
import re

# Misc functions for AES
pad = lambda data : data + chr((16 - len(data) % 16)) * (16 - len(data) % 16)
unpad = lambda s : s[:-ord(s[len(s)-1:])]
sha256sum = lambda data: hashlib.sha256(data.encode('utf-8')).hexdigest()

# Help with str/byte representations
getstr = lambda data: data.decode('utf-8') if isinstance(data, bytes) else data
getbytes = lambda data: data.encode('utf-8') if isinstance(data, str) else data

# Hashing parameters
g = 2223524560805841909784646199263433401086381756659699723752850466750539890685682851537264748143133524324860590492305324285765696739843206245501757489206611015735942968782484497005489603880421919871382821578419645350866547730472154357187591520409002351603869773893242348718572354381172392785594341070332718566289
p = 62565723754058110134184001269265026995419782768569177086204348747687732348848236769229781932708360465701357972344794565740615466515350423240090663020164879389985960193699399021364476070220725008450692501480668763322130258028788020093565050589724307750757980284019043386143246778466757018917406796414009849419506348774472169291285638213327375088919193217225759978659412101547650960434445699162046310136838178962085668568787752550883666134594662568820237321652729335696495208126896696594655696472740672048375181433229185450187517242248770941384487990146267643257056551996515645627561800669155515249895921530521876406192277

def encrypt(msg, key):
    # Calculate the hashes
    hash_1 = str(pow(g, key, p))
    hash_2 = sha256sum(str(key) + str(sum([int(d) for d in str(key)])) + hex(key))

    # Encrypt msg
    msg, key = pad(msg), pad(str(key))
    IV = Random.new().read(16)
    enc = IV + AES.new(key, AES.MODE_CBC, IV).encrypt(msg)
    glob = getbytes((hash_1 + '|'  + getstr(base64.b64encode(enc)) + '|' + hash_2))
    return base64.b64encode(zlib.compress(glob))

def decrypt(msg, key):
    # Parse the structure
    msg = re.sub("\-{5}(\w+\s){2}\w+\-{5}\n", "", msg).replace('\n','')
    msg = getstr(zlib.decompress(base64.b64decode(msg))).split('|')
    hash1 = int(msg[0])
    enc = base64.b64decode(msg[1])
    hash2 = msg[2]

    # Verify hash 1
    if not pow(g, key, p) == hash1:
        print('[!] Invalid key')
        sys.exit(0)

    # Verify hash 2
    key = str(key)
    if not sha256sum(key + str(sum([int(d) for d in key])) + hex(int(key))) == hash2:
        print('[!] Invalid key')
        sys.exit(0)

    # Decrypt the message
    key = pad(key)
    IV = enc[:16]
    return unpad(AES.new(key, AES.MODE_CBC, IV).decrypt(enc[16:]))

# Must use python 3
if sys.version_info[0] < 3:
    print("[!] The unicorns are modern. Please use python 3 or greater")
    sys.exit(0)

# Must supply an option
if len(sys.argv) < 2:
    print('[!] Too few arguments!')
    sys.exit(0)

# If they are generating a unicon encrypt message
if sys.argv[1] == '-e':
    try:
        # Encrypt message
        key = int(input('Key: '))
        msg = input('Message: ')
        e = encrypt(msg, key)

        # Write to file
        with open('encrypted.rzt', 'wb') as f:
            f.write(b'-----BEGIN UNICORN MESSAGE-----\n')
            for i in range(0, len(e), 50):
                f.write(e[i:i + 50] + b'\n')
            f.write(b'-----END UNICORN MESSAGE-----\n')

    # Error occured, quit
    except Exception as e:
        print('[!] Error: %s' % e)
        sys.exit(1)
    print('[+] Encrypted message saved to encrypted.rzt')

# If they are decrypting a unicorn encrypted message
elif sys.argv[1] == '-d':
    try:
        # Read input
        key = int(input('Key: '))
        efile = input('Encrypted file: ')
        with open(efile, 'rb') as f:
            e = f.read()

        # Attempt decrypt of data
        d = decrypt(getstr(e), key)
        with open('decrypted.rzt', 'wb') as f:
            f.write(d)

    # Error occured, quit
    except Exception as e:
        print('[!] Error: %s' % e)
        sys.exit(1)
    print('[+] Decrypted file saved to decrypted.rzt')

# No valid option selected, print help menu
else:
    print('Usage: python3 ./%s [OPTION]\n' % sys.argv[0])
    print('Options:\n  -e : Encrypt a message\n  -d : Decrypt a message')