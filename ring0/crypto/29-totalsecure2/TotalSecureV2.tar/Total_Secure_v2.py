#!/usr/bin/python

#Define the Curve
P = 115792089210356248762697446949407573530086143415290314195533631308867097853951
A = 115792089210356248762697446949407573530086143415290314195533631308867097853948
B = 41058363725152142129326129780047268409114441015993725554835256314039467401291
C = "47283773153164809794594396048532183165183737859644618253271193841279757371677 30178178881440124296661645666748623857000098435819181780716332332299327851071"
D = "88201848404337653530352341104926177269734697465416399199280599946178535043047 78191526375329609816386437007126976825033060282440200914139627774911707453518"
Dx, Dy = [int(i) for i in D.strip().split()]
Cx, Cy = [int(i) for i in C.strip().split()]

# Source: Wikibooks
def egcd(a, b):
    x,y, u,v = 0,1, 1,0
    while a != 0:
        q, r = b//a, b%a
        m, n = x-u*q, y-v*q
        b,a, x,y, u,v = a,r, u,v, m,n
    gcd = b
    return gcd, x, y

def inv(a):
    gcd, x, y = egcd(a % P, P)
    if gcd != 1:
        return -1
    else:
        return x % P

def add(a, b):
    if a == 0:
        return b
    if b == 0:
        return a
    i = inv(b[0] - a[0])
    if i == -1:
        return 0
    l = ((b[1] - a[1]) * i) % P
    x = (l*l - a[0] - b[0]) % P
    y = (l*(a[0] - x) - a[1]) % P
    return (x,y)

def double(a):
    if a == 0:
        return a
    i = inv(2*a[1])
    if i == -1:
        return 0
    l = ((3*a[0]*a[0] + A) * i) % P
    x = (l*l - 2*a[0]) % P
    y = (l*(a[0] - x) - a[1]) % P
    return (x,y)

def multiply(point, exponent):
    r0 = 0
    r1 = point
    for i in bin(exponent)[2:]:
        if i == '0':
            r1 = add(r0, r1)
            r0 = double(r0)
        else:
            r0 = add(r0, r1)
            r1 = double(r1)
    return r0

def generate():
	global z
	f = multiply((Dx, Dy), z)[0]
	z = multiply((Dx, Dy), f)[0]
	return multiply((Cx, Cy), f)

#Get message and Encrypt it
def Encrypt():
	print "Encrypting Message..."
	message = int(raw_input("Message To Encrypt: ").encode('hex'), 16);key = ''
	while(len(key)<=len(str(message))):
		K = generate()[0]
		key += str(K)
	return str(int(key) ^ message)

#Get Password
z = int(raw_input("Password: ").encode('hex'), 16)

#Encrypt the message and print it
coded = Encrypt()
print "\n---Total Secure Message Encrypter V2.0 ---"
print "        ++ Format: ringzer0team ++"
print coded
print "---End Total Secure Message Encrypter Message---"